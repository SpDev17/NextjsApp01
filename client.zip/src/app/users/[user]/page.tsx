
//import { useRouter } from "next/router";
const user = () => {
    //const router = useRouter();
    return <p>User :</p>
}

export default user;