import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
export default async function serverPage() {
    const session = await getServerSession();
    if (!session) {
        redirect('/api/auth/signin?callbackUrl=/');
    }
    return (<main>
        server page
    </main>)
}