export default function About() {
  return (<div className="flex items-top justify-left p-6 md:w-4/5 md:px-2 md:py-12 bg-gray-50">About Us</div>);
  }