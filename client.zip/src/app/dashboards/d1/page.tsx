'use client';
import React from "react";
const d1 = () => {
    //const router = useRouter();
    return (<div className="flex items-center justify-left p-6 md:w-4/5 md:px-2 md:py-12 bg-gray-50">Dashboard 1 Home page</div>);
}

export default d1;