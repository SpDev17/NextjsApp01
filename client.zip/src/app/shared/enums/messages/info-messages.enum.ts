export enum InfoMessages {
    DatabasesConnected = 'Databases connected successfully!',
  }