export enum SpecialMessages {
    Redacted = '*****',
    DottedLine = '. . . . . . .',
}