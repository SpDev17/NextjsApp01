export enum MongooseErrorCodes {
    UniqueConstraintFail = 11000
}

export enum MongooseErrors {
    MongoServerError = 'MongoServerError'
}