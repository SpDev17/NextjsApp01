/**
 * Define sensitive keys you want to remove from logs
 */
export enum SensitiveKeys {
    Password = 'password',
    NewPassword = 'new_password',
    OldPassword = 'old_password',
    RepeatPassword = 'repeat_password'
}